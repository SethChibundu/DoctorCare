# DoctorCare
Is a simple landing page for the DoctorCare application
